const http = require('http');

function makeRequest(options, data) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, res => {
      let body = '';
      res.on('data', d => { body += d; });
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(body) });
        } catch {
          resolve({ status: res.statusCode, body });
        }
      });
    });
    req.on('error', reject);
    if (data) req.write(data);
    req.end();
  });
}

async function runTests() {
  console.log('Testing Brown Bean Cafe API...\n');
  
  const validOrder = {
    customer: { name: 'Test User', phone: '1234567890', address: '123 Test St' },
    items: [{ name: 'Coffee', price: 250, quantity: 2 }],
    total: 500
  };

  // Test 1: Health check
  console.log('1. Health check...');
  const health = await makeRequest({
    hostname: 'localhost',
    port: 3000,
    path: '/api/health',
    method: 'GET'
  });
  console.log(`   Status: ${health.status} - ${health.status === 200 ? 'PASS' : 'FAIL'}\n`);

  // Test 2: Valid order
  console.log('2. Placing valid order...');
  const order = await makeRequest({
    hostname: 'localhost',
    port: 3000,
    path: '/api/orders',
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': JSON.stringify(validOrder).length }
  }, JSON.stringify(validOrder));
  console.log(`   Status: ${order.status} - ${order.status === 201 ? 'PASS' : 'FAIL'}`);
  console.log(`   Response:`, order.body);

  if (order.body.orderId) {
    // Test 3: Get order by ID
    console.log('\n3. Getting order by ID...');
    const getOrder = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: `/api/orders/${order.body.orderId}`,
      method: 'GET'
    });
    console.log(`   Status: ${getOrder.status} - ${getOrder.status === 200 ? 'PASS' : 'FAIL'}\n`);

    // Test 4: Get all orders
    console.log('4. Getting all orders...');
    const allOrders = await makeRequest({
      hostname: 'localhost',
      port: 3000,
      path: '/api/orders',
      method: 'GET'
    });
    console.log(`   Status: ${allOrders.status} - ${Array.isArray(allOrders.body) ? 'PASS' : 'FAIL'}`);
    console.log(`   Orders found: ${allOrders.body.length || 0}\n`);
  }

  // Test 5: Invalid order (missing fields)
  console.log('5. Invalid order (missing fields)...');
  const invalidData = JSON.stringify({});
  const invalid = await makeRequest({
    hostname: 'localhost',
    port: 3000,
    path: '/api/orders',
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(invalidData) }
  }, invalidData);
  console.log(`   Status: ${invalid.status} - ${invalid.status === 400 ? 'PASS' : 'FAIL'}\n`);

  console.log('Tests completed!');
}

runTests().catch(console.error);
