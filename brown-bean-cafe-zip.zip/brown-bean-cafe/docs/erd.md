# Database ERD - Brown Bean Cafe

![Database ERD](./assets/erd.png)

This diagram represents the Entity Relationship Structure of the Brown Bean Cafe database.

```mermaid
erDiagram
    admin_users {
        int id PK
        string username
        string password
        datetime created_at
    }

    categories {
        int id PK
        string name
    }

    menu_items {
        int id PK
        string name
        string category
        decimal price
        datetime created_at
    }

    customers {
        int id PK
        string name
        string phone
        text address
        datetime created_at
    }

    orders {
        int id PK
        int customer_id FK
        decimal total_price
        enum status
        datetime order_time
    }

    order_items {
        int id PK
        int order_id FK
        string item_name
        decimal item_price
        int quantity
    }

    payments {
        int id PK
        int order_id FK
        string method
        enum status
        datetime payment_time
    }

    deliveries {
        int id PK
        int order_id FK
        string status
        string assigned_to
    }

    customers ||--o{ orders : "places"
    orders ||--o{ order_items : "contains"
    orders ||--o| payments : "has"
    orders ||--o| deliveries : "scheduled"
```

### Table Relationships:
- **Customers to Orders:** One-to-Many (One customer can place many orders).
- **Orders to Order Items:** One-to-Many (One order can contain multiple menu items).
- **Orders to Payments:** One-to-One/Many (Each order is associated with a payment record).
- **Orders to Deliveries:** One-to-One (Each order has one delivery tracking record).
