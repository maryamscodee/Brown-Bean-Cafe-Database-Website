require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const db = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Validation helpers
function isValidPhone(phone) {
  return /^[0-9+\-\s()]{7,20}$/.test(phone);
}

function isValidName(name) {
  return typeof name === 'string' && name.trim().length >= 2 && name.length <= 100;
}

// ==========================================
// CUSTOMER APIS
// ==========================================

// Get menu items for customer page
app.get('/api/menu', async (req, res) => {
  try {
    const [items] = await db.execute('SELECT * FROM menu_items ORDER BY category, name');
    res.json(items);
  } catch (err) {
    console.error('Error fetching menu:', err);
    res.status(500).json({ error: 'Failed to fetch menu' });
  }
});

// API endpoint to place orders
app.post('/api/orders', async (req, res) => {
  const { customer, items, total, paymentMethod } = req.body;

  if (!customer || !items || !total || !paymentMethod) {
    return res.status(400).json({ error: 'Missing required order details' });
  }

  if (!isValidName(customer.name)) return res.status(400).json({ error: 'Invalid customer name' });
  if (!isValidPhone(customer.phone)) return res.status(400).json({ error: 'Invalid phone number' });

  try {
    const connection = await db.getConnection();
    
    try {
      await connection.beginTransaction();

      // 1. Insert/Get Customer
      const [customerResult] = await connection.execute(
        'INSERT INTO customers (name, phone, address) VALUES (?, ?, ?)',
        [customer.name.trim(), customer.phone.trim(), customer.address || '']
      );
      const customerId = customerResult.insertId;

      // 2. Create Order
      const [orderResult] = await connection.execute(
        'INSERT INTO orders (customer_id, total_price, status) VALUES (?, ?, ?)',
        [customerId, total, 'Pending']
      );
      const orderId = orderResult.insertId;

      // 3. Create Order Items
      for (const item of items) {
        await connection.execute(
          'INSERT INTO order_items (order_id, item_name, item_price, quantity) VALUES (?, ?, ?, ?)',
          [orderId, item.name, item.price, item.quantity]
        );
      }

      // 4. Create Payment
      await connection.execute(
        'INSERT INTO payments (order_id, method, status) VALUES (?, ?, ?)',
        [orderId, paymentMethod, 'Pending']
      );

      // 5. Create Delivery
      await connection.execute(
        'INSERT INTO deliveries (order_id, status) VALUES (?, ?)',
        [orderId, 'Pending']
      );

      await connection.commit();
      res.status(201).json({ success: true, message: 'Order placed successfully', orderId });
    } catch (err) {
      await connection.rollback();
      throw err;
    } finally {
      connection.release();
    }
  } catch (err) {
    console.error('Error placing order:', err);
    res.status(500).json({ error: 'Failed to place order' });
  }
});

// ==========================================
// ADMIN APIS
// ==========================================

// Admin Login
app.post('/api/admin/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const [users] = await db.execute('SELECT * FROM admin_users WHERE username = ? AND password = ?', [username, password]);
    if (users.length > 0) {
      res.json({ success: true, token: 'fake-admin-token-' + Date.now() });
    } else {
      res.status(401).json({ error: 'Invalid credentials' });
    }
  } catch (err) {
    res.status(500).json({ error: 'Login failed' });
  }
});

// Dashboard Stats
app.get('/api/admin/stats', async (req, res) => {
  try {
    const [[{ totalOrders }]] = await db.execute('SELECT COUNT(*) as totalOrders FROM orders');
    const [[{ totalItems }]] = await db.execute('SELECT COUNT(*) as totalItems FROM menu_items');
    res.json({ totalOrders, totalItems });
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Manage Menu Items
app.get('/api/admin/menu', async (req, res) => {
  try {
    const [items] = await db.execute('SELECT * FROM menu_items ORDER BY created_at DESC');
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch menu' });
  }
});

app.post('/api/admin/menu', async (req, res) => {
  const { name, category, price } = req.body;
  try {
    await db.execute('INSERT INTO menu_items (name, category, price) VALUES (?, ?, ?)', [name, category, price]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to add item' });
  }
});

app.put('/api/admin/menu/:id', async (req, res) => {
  const { name, category, price } = req.body;
  try {
    await db.execute('UPDATE menu_items SET name=?, category=?, price=? WHERE id=?', [name, category, price, req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update item' });
  }
});

app.delete('/api/admin/menu/:id', async (req, res) => {
  try {
    await db.execute('DELETE FROM menu_items WHERE id=?', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete item' });
  }
});

// View Orders
app.get('/api/admin/orders', async (req, res) => {
  try {
    const [orders] = await db.execute(`
      SELECT o.*, c.name as customer_name, c.phone as customer_phone, c.address as customer_address, p.method as payment_method
      FROM orders o
      JOIN customers c ON o.customer_id = c.id
      JOIN payments p ON o.id = p.order_id
      ORDER BY o.order_time DESC
    `);

    for (let order of orders) {
      const [items] = await db.execute('SELECT * FROM order_items WHERE order_id = ?', [order.id]);
      order.items = items;
    }

    res.json(orders);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch orders' });
  }
});

// Update Order Status
app.put('/api/admin/orders/:id/status', async (req, res) => {
  const { status } = req.body;
  try {
    await db.execute('UPDATE orders SET status = ? WHERE id = ?', [status, req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update status' });
  }
});

// Health check
app.get('/api/health', async (req, res) => {
  try {
    await db.execute('SELECT 1');
    res.json({ status: 'ok', timestamp: new Date().toISOString() });
  } catch (err) {
    res.status(503).json({ status: 'error', message: 'Database unavailable' });
  }
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
