// Cart Management
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Check server connection
window.addEventListener('load', () => {
  document.body.style.opacity = '0';
  setTimeout(() => {
    document.body.style.transition = 'opacity 0.3s ease';
    document.body.style.opacity = '1';
  }, 50);

  fetch(`${window.location.origin}/api/health`)
    .then(r => r.json())
    .then(data => {
      if (data.status !== 'ok') {
        alert('Warning: Server connection issue. Orders may not work.');
      }
    })
    .catch(() => {
      if (window.location.protocol === 'file:') {
        alert('Please access this site via http://localhost:3000 instead of opening the file directly.');
      } else {
        alert('Cannot connect to server. Please make sure the server is running at http://localhost:3000');
      }
    });

  loadMenu();
});

async function loadMenu() {
  const menuCategories = document.getElementById('menuCategories');
  if (!menuCategories) return;

  try {
    const response = await fetch(`${window.location.origin}/api/menu`);
    const items = await response.json();

    if (items.error) {
      console.error('Error loading menu:', items.error);
      return;
    }

    // Group items by category
    const groupedItems = items.reduce((acc, item) => {
      if (!acc[item.category]) acc[item.category] = [];
      acc[item.category].push(item);
      return acc;
    }, {});

    // Category icons mapping
    const categoryIcons = {
      'Appetizers': '',
      'Main Course': '🍗 ',
      'Desserts': '🍰 ',
      'Drinks': '🥤 '
    };

    // Render each category
    menuCategories.innerHTML = Object.keys(groupedItems).map(category => `
      <div class="category animate">
        <h3>${categoryIcons[category] || ''}${category}</h3>
        <div class="menu-grid">
          ${groupedItems[category].map(item => `
            <div class="menu-item">
              <h4>${item.name}</h4>
              <div class="price">Rs. ${parseFloat(item.price).toLocaleString()}</div>
              <button class="add-btn" onclick="addToCart('${item.name.replace(/'/g, "\\'")}', ${item.price})">Add to Cart</button>
            </div>
          `).join('')}
        </div>
      </div>
    `).join('');

  } catch (error) {
    console.error('Failed to fetch menu:', error);
  }
}

function addToCart(name, price) {
  const existingItem = cart.find(item => item.name === name);

  if (existingItem) {
    existingItem.quantity += 1;
  } else {
    cart.push({ name, price, quantity: 1 });
  }

  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartDisplay();

  // Visual feedback
  const btn = event.target;
  btn.textContent = 'Added! ✓';
  btn.classList.add('added');

  setTimeout(() => {
    btn.textContent = 'Add to Cart';
    btn.classList.remove('added');
  }, 1500);

  showNotification('Item added to cart!');
}

function updateCartDisplay() {
  const cartCount = document.getElementById('cartCount');
  const cartContainer = document.getElementById('cartContainer');
  const emptyCart = document.getElementById('emptyCart');
  const cartItems = document.getElementById('cartItems');
  const cartTotal = document.getElementById('cartTotal');
  const checkoutBtn = document.getElementById('checkoutBtn');

  cartCount.textContent = cart.reduce((sum, item) => sum + item.quantity, 0);

  if (cart.length > 0) {
    cartContainer.style.display = 'block';
    emptyCart.style.display = 'none';
    checkoutBtn.style.display = 'inline-block';

    cartItems.innerHTML = cart.map((item, index) => `
      <div class="cart-item">
        <div class="cart-details">
          <h4>${item.name}</h4>
          <div>Rs. ${item.price.toLocaleString()} × ${item.quantity}</div>
        </div>
        
        <div>
          <div class="quantity-controls">
            <button class="qty-btn" onclick="updateQuantity(${index}, -1)">−</button>
            <span style="font-weight: bold; font-size: 1.2rem; min-width: 30px; text-align: center;">${item.quantity}</span>
            <button class="qty-btn" onclick="updateQuantity(${index}, 1)">+</button>
          </div>
          
          <div style="margin-top: 10px;">
            <button class="remove-btn" onclick="removeItem(${index})">Remove</button>
          </div>
          
          <div style="font-weight: bold; color: var(--coffee-brown); margin-top: 10px;">
            Rs. ${(item.price * item.quantity).toLocaleString()}
          </div>
        </div>
      </div>
    `).join('');

    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    cartTotal.textContent = total.toLocaleString();

  } else {
    cartContainer.style.display = 'none';
    emptyCart.style.display = 'block';
    checkoutBtn.style.display = 'none';
  }
}

function updateQuantity(index, change) {
  if (cart[index].quantity + change > 0) {
    cart[index].quantity += change;

    if (cart[index].quantity === 0) {
      cart.splice(index, 1);
    }

    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
  }
}

function removeItem(index) {
  cart.splice(index, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartDisplay();
  showNotification('Item removed from cart!');
}

function showOrderForm() {
  document.getElementById('cartContainer').style.display = 'none';
  document.getElementById('orderForm').style.display = 'block';
  document.getElementById('cart').scrollIntoView({ behavior: 'smooth' });
}

function backToCart() {
  document.getElementById('orderForm').style.display = 'none';
  document.getElementById('cartContainer').style.display = 'block';
}

// Order placement
document.getElementById('customerForm').addEventListener('submit', function(e) {
  e.preventDefault();

  const paymentMethod = document.querySelector('input[name="paymentMethod"]:checked');
  
  if (!paymentMethod) {
    alert('Please select a payment method');
    return;
  }

  const orderData = {
    customer: {
      name: document.getElementById('customerName').value,
      phone: document.getElementById('customerPhone').value,
      address: document.getElementById('customerAddress').value
    },
    paymentMethod: paymentMethod.value,
    items: cart,
    total: cart.reduce((sum, item) => sum + (item.price * item.quantity), 0)
  };

  const checkoutBtn = document.querySelector('.order-form button[type="submit"]');
  const originalText = checkoutBtn.textContent;
  checkoutBtn.textContent = 'Placing Order...';
  checkoutBtn.disabled = true;

  fetch(`${window.location.origin}/api/orders`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(orderData)
  })
  .then(response => response.json())
  .then(data => {
    if (data.error) {
      alert('Order failed: ' + data.error);
      return;
    }
    if (data.success || data.orderId) {
      // Clear cart
      cart = [];
      localStorage.setItem('cart', JSON.stringify(cart));

      alert(`Order placed successfully!\nTotal: Rs. ${orderData.total.toLocaleString()}\n\nWe'll call you shortly to confirm. Thank you! ☕`);

      document.getElementById('customerForm').reset();
      backToCart();
      updateCartDisplay();
      
      // Scroll to top
      document.getElementById('home').scrollIntoView({ behavior: 'smooth' });
    } else {
      alert(data.error || 'Failed to place order.');
    }
  })
  .catch(error => {
    console.error('Error placing order:', error);
    alert('An error occurred: ' + (error.message || error || 'Please try again later.'));
  })
  .finally(() => {
    checkoutBtn.textContent = originalText;
    checkoutBtn.disabled = false;
  });
});

function showNotification(message) {
  const notification = document.createElement('div');
  
  notification.style.cssText = `
    position: fixed;
    top: 100px;
    right: 20px;
    background: var(--accent-gold);
    color: var(--coffee-brown);
    padding: 15px 25px;
    border-radius: 25px;
    box-shadow: 0 5px 20px rgba(212,175,55,0.4);
    z-index: 1000;
    font-weight: bold;
    transform: translateX(400px);
    transition: all 0.3s ease;
  `;
  
  notification.textContent = message;
  document.body.appendChild(notification);

  setTimeout(() => {
    notification.style.transform = 'translateX(0)';
  }, 100);

  setTimeout(() => {
    notification.remove();
  }, 3000);
}

// Smooth scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function (e) {
    e.preventDefault();
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
  });
});

// Init
document.addEventListener('DOMContentLoaded', function() {
  updateCartDisplay();
  // loadMenu is called in the window load event to ensure server health check runs first
});
