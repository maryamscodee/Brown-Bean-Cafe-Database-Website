// Authentication State
let token = localStorage.getItem('adminToken');

// DOM Elements
const loginPage = document.getElementById('loginPage');
const dashboardPage = document.getElementById('dashboardPage');
const adminLoginForm = document.getElementById('adminLoginForm');
const logoutBtn = document.getElementById('logoutBtn');
const navLinks = document.querySelectorAll('.nav-link');
const sections = document.querySelectorAll('.dashboard-section');

// Init
document.addEventListener('DOMContentLoaded', () => {
  if (token) {
    showDashboard();
  }
});

// Login Logic
adminLoginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('adminUsername').value;
  const password = document.getElementById('adminPassword').value;

  try {
    const response = await fetch('/api/admin/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });
    const data = await response.json();

    if (data.success) {
      token = data.token;
      localStorage.setItem('adminToken', token);
      showDashboard();
    } else {
      alert(data.error || 'Login failed');
    }
  } catch (err) {
    alert('An error occurred during login');
  }
});

// Logout
logoutBtn.addEventListener('click', () => {
  localStorage.removeItem('adminToken');
  location.reload();
});

// Dashboard Management
function showDashboard() {
  loginPage.style.display = 'none';
  dashboardPage.style.display = 'flex';
  loadStats();
  loadRecentOrders();
}

// Navigation
navLinks.forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const sectionId = link.getAttribute('data-section');
    
    navLinks.forEach(l => l.classList.remove('active'));
    link.classList.add('active');

    sections.forEach(sec => sec.style.display = 'none');
    
    if (sectionId === 'overview') {
      document.getElementById('overviewSection').style.display = 'block';
      document.getElementById('sectionTitle').innerText = 'Dashboard Overview';
      loadStats();
      loadRecentOrders();
    } else if (sectionId === 'menu-mgmt') {
      document.getElementById('menuSection').style.display = 'block';
      document.getElementById('sectionTitle').innerText = 'Manage Menu Items';
      loadMenu();
    } else if (sectionId === 'orders-mgmt') {
      document.getElementById('ordersSection').style.display = 'block';
      document.getElementById('sectionTitle').innerText = 'Customer Orders';
      loadOrders();
    }
  });
});

// Stats API
async function loadStats() {
  try {
    const res = await fetch('/api/admin/stats');
    const data = await res.json();
    document.getElementById('totalOrders').innerText = data.totalOrders;
    document.getElementById('totalMenuItems').innerText = data.totalItems;
  } catch (err) { console.error('Stats error:', err); }
}

// Recent Orders API (for overview)
async function loadRecentOrders() {
  try {
    const res = await fetch('/api/admin/orders');
    const orders = await res.json();
    const tbody = document.querySelector('#recentOrdersTable tbody');
    tbody.innerHTML = orders.slice(0, 5).map(o => `
      <tr>
        <td>#${o.id}</td>
        <td>${o.customer_name}</td>
        <td>Rs. ${o.total_price}</td>
        <td><span class="status-badge status-${o.status.toLowerCase().replace(/\s/g, '')}">${o.status}</span></td>
      </tr>
    `).join('');
  } catch (err) { console.error('Orders error:', err); }
}

// Menu Management
async function loadMenu() {
  try {
    const res = await fetch('/api/admin/menu');
    const items = await res.json();
    const tbody = document.querySelector('#menuTable tbody');
    tbody.innerHTML = items.map(item => `
      <tr>
        <td>${item.name}</td>
        <td>${item.category}</td>
        <td>Rs. ${item.price}</td>
        <td>
          <button class="action-btn btn-edit" onclick="editItem(${item.id}, '${item.name}', '${item.category}', ${item.price})">Edit</button>
          <button class="action-btn btn-delete" onclick="deleteItem(${item.id})">Delete</button>
        </td>
      </tr>
    `).join('');
  } catch (err) { console.error('Menu error:', err); }
}

function openMenuModal() {
  document.getElementById('menuModal').style.display = 'flex';
  document.getElementById('modalTitle').innerText = 'Add Menu Item';
  document.getElementById('menuForm').reset();
  document.getElementById('menuItemId').value = '';
}

function closeMenuModal() {
  document.getElementById('menuModal').style.display = 'none';
}

function editItem(id, name, category, price) {
  openMenuModal();
  document.getElementById('modalTitle').innerText = 'Edit Menu Item';
  document.getElementById('menuItemId').value = id;
  document.getElementById('itemName').value = name;
  document.getElementById('itemCategory').value = category;
  document.getElementById('itemPrice').value = price;
}

document.getElementById('menuForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('menuItemId').value;
  const name = document.getElementById('itemName').value;
  const category = document.getElementById('itemCategory').value;
  const price = document.getElementById('itemPrice').value;

  const url = id ? `/api/admin/menu/${id}` : '/api/admin/menu';
  const method = id ? 'PUT' : 'POST';

  try {
    await fetch(url, {
      method,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, category, price })
    });
    closeMenuModal();
    loadMenu();
  } catch (err) { alert('Save failed'); }
});

async function deleteItem(id) {
  if (!confirm('Are you sure you want to delete this item?')) return;
  try {
    await fetch(`/api/admin/menu/${id}`, { method: 'DELETE' });
    loadMenu();
  } catch (err) { alert('Delete failed'); }
}

// Orders Management
async function loadOrders() {
  try {
    const res = await fetch('/api/admin/orders');
    const orders = await res.json();
    const tbody = document.querySelector('#ordersTable tbody');
    tbody.innerHTML = orders.map(o => `
      <tr>
        <td>${new Date(o.order_time).toLocaleString()}</td>
        <td>
          <strong>${o.customer_name}</strong><br>
          ${o.customer_phone}<br>
          <small>${o.customer_address}</small>
        </td>
        <td>
          ${o.items.map(i => `${i.item_name} (x${i.quantity})`).join('<br>')}
        </td>
        <td>${o.payment_method}</td>
        <td><strong>Rs. ${o.total_price}</strong></td>
        <td>
          <select onchange="updateStatus(${o.id}, this.value)" class="status-badge status-${o.status.toLowerCase().replace(/\s/g, '')}">
            <option value="Pending" ${o.status === 'Pending' ? 'selected' : ''}>Pending</option>
            <option value="Preparing" ${o.status === 'Preparing' ? 'selected' : ''}>Preparing</option>
            <option value="Out for Delivery" ${o.status === 'Out for Delivery' ? 'selected' : ''}>Out for Delivery</option>
            <option value="Delivered" ${o.status === 'Delivered' ? 'selected' : ''}>Delivered</option>
          </select>
        </td>
        <td>
          <button class="action-btn btn-edit" onclick="alert('Order ID: ${o.id}')">Details</button>
        </td>
      </tr>
    `).join('');
  } catch (err) { console.error('Orders error:', err); }
}

async function updateStatus(id, newStatus) {
  try {
    await fetch(`/api/admin/orders/${id}/status`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: newStatus })
    });
    loadOrders();
  } catch (err) { alert('Status update failed'); }
}
